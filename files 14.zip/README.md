# Lius Pros — Setup Guide

## Quick Start

### 1. Supabase Setup

1. Go to [supabase.com](https://supabase.com) and create a new project
2. In the SQL Editor, run the following to create your tables:

```sql
-- Products table
CREATE TABLE products (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  price numeric NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Slots table
CREATE TABLE slots (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id uuid REFERENCES products(id),
  login_email text NOT NULL,
  login_password text NOT NULL,
  profile_name text,
  status text DEFAULT 'available',
  created_at timestamptz DEFAULT now()
);

-- Orders table
CREATE TABLE orders (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  customer_email text NOT NULL,
  whatsapp text,
  product_id uuid REFERENCES products(id),
  slot_id uuid REFERENCES slots(id),
  payment_reference text,
  status text DEFAULT 'completed',
  created_at timestamptz DEFAULT now()
);

-- RLS Policies (enable public reads for products/slots count, and inserts for orders)
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE slots ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

-- Allow public to read products
CREATE POLICY "Public read products" ON products FOR SELECT USING (true);

-- Allow public to read slots (count only — no credentials exposed before payment)
CREATE POLICY "Public read slots" ON slots FOR SELECT USING (true);

-- Allow public to update slot status (after payment)
CREATE POLICY "Public update slots" ON slots FOR UPDATE USING (true);

-- Allow public to insert orders
CREATE POLICY "Public insert orders" ON orders FOR SELECT USING (true);
CREATE POLICY "Insert orders" ON orders FOR INSERT WITH CHECK (true);
```

3. Get your **Project URL** and **anon/public key** from Settings → API

### 2. Configure app.js

Open `app.js` and replace the placeholder values:

```js
const SUPABASE_URL  = 'https://YOUR_PROJECT.supabase.co';  // ← your project URL
const SUPABASE_ANON = 'YOUR_ANON_KEY';                      // ← your anon key
const PAYSTACK_KEY  = 'pk_test_YOUR_PAYSTACK_PUBLIC_KEY';   // ← Paystack public key

const EMAILJS_SERVICE  = 'YOUR_EMAILJS_SERVICE_ID';
const EMAILJS_TEMPLATE = 'YOUR_EMAILJS_TEMPLATE_ID';
const EMAILJS_USER     = 'YOUR_EMAILJS_PUBLIC_KEY';
```

### 3. Paystack Setup

1. Sign up at [paystack.com](https://paystack.com)
2. Get your **Public Key** from Settings → API Keys
3. Replace `PAYSTACK_KEY` in `app.js`

### 4. EmailJS Setup

1. Sign up at [emailjs.com](https://emailjs.com)
2. Create an Email Service (Gmail, etc.)
3. Create an Email Template with these variables:
   - `{{to_email}}` — recipient
   - `{{product_name}}` — subscription name
   - `{{login_email}}` — account email
   - `{{login_password}}` — account password
   - `{{profile_name}}` — profile (for Netflix, etc.)
4. Copy your Service ID, Template ID, and Public Key into `app.js`

### 5. Deploy

Upload all files to any static hosting:
- **Netlify**: drag-and-drop the folder
- **Vercel**: `vercel deploy`
- **GitHub Pages**: push to a repo and enable Pages

---

## Admin Panel

- URL: `/admin.html`
- Password: `admin123`

**Change the password** by editing this line in `admin.html`:
```js
const ADMIN_PASSWORD = 'admin123';
```

---

## File Structure

```
lius-pros/
├── index.html       Homepage
├── products.html    All plans listing
├── checkout.html    Payment page
├── success.html     Post-payment credentials page
├── dashboard.html   Customer order lookup
├── admin.html       Admin panel
├── style.css        All styles
└── app.js           Shared config, Supabase client, utilities
```

---

## Security Notes

- Slot credentials are only accessible after a verified Paystack payment
- The admin panel is password-protected (client-side — for production, use Supabase Auth)
- All payments are processed by Paystack — no card data touches your server
- Consider enabling Supabase RLS policies to restrict direct database access
